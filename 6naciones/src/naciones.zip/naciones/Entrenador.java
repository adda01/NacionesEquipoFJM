package naciones;

import java.sql.Date;
import java.util.ArrayList;

public class Entrenador {
	
	 private int experiencia;
	    private ArrayList<Equipo> equipo;


	    public Entrenador() {
	        experiencia = 0;
	        equipo = new ArrayList<>();
	    }

	    public Entrenador(Entrenador entrenador) {
	        experiencia = entrenador.experiencia;
	        equipo = new ArrayList<>();
	        for (Equipo equipo : entrenador.equipo) {
	            this.equipo.add(new Equipo(equipo));
	        }
	    }

	    public Entrenador(String nombre, String apellidos, int edad, String nacionalidad, String nombreCompleto, double peso, Date fechaNacimiento, int experiencia, ArrayList<Equipo> equipo) {
	        super();
	        this.experiencia = experiencia;
	        this.equipo = equipo;
	    }

	    public int getExperiencia() {
	        return experiencia;
	    }

	    public void setExperiencia(int experiencia) {
	        this.experiencia = experiencia;
	    }

	    public ArrayList<Equipo> getEquipo() {
	        return equipo;
	    }

	    public void setEquipo(ArrayList<Equipo> equipo) {
	        this.equipo = equipo;
	    }

	    @Override
	    public String toString() {
	        return "Entrenador{" + "experiencia=" + experiencia + ", equipo=" + equipo + '}';
	    }
	    

}
