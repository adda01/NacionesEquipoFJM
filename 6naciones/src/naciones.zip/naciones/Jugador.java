package naciones;

import java.sql.Date;
import java.util.ArrayList;

public class Jugador extends Persona {
	
	private ArrayList<Equipo> equipo;
    private int velocidad;
    private int fuerza;
    private int resistencia;

    public Jugador() {
        super();
        equipo = new ArrayList<>();
        velocidad = 0;
        fuerza = 0;
        resistencia = 0;
    }

    public Jugador(Jugador jugador) {
        super();
        equipo = new ArrayList<>();
        for (Equipo equipo : jugador.equipo) {
            this.equipo.add(new Equipo(equipo));
        }
        velocidad = jugador.velocidad;
        fuerza = jugador.fuerza;
        resistencia = jugador.resistencia;
    }

    public Jugador(String nombre, String apellidos, int edad, String nacionalidad, String nombreCompleto, double peso, Date fechaNacimiento, ArrayList<Equipo> equipo, int velocidad, int fuerza, int resistencia) {
        super(nombreCompleto, peso,  fechaNacimiento);
        this.equipo = equipo;
        this.velocidad = velocidad;
        this.fuerza = fuerza;
        this.resistencia = resistencia;
    }

    public ArrayList<Equipo> getEquipo() {
        return equipo;
    }

    public void setEquipo(ArrayList<Equipo> equipo) {
        this.equipo = equipo;
    }

    public int getVelocidad() {
        return velocidad;
    }

    public void setVelocidad(int velocidad) {
        this.velocidad = velocidad;
    }

    public int getFuerza() {
        return fuerza;
    }

    public void setFuerza(int fuerza) {
        this.fuerza = fuerza;
    }

    public int getResistencia() {
        return resistencia;
    }

    public void setResistencia(int resistencia) {
        this.resistencia = resistencia;
    }

    @Override
    public String toString() {
        return "Jugador{" +
                "equipo=" + equipo +
                ", velocidad=" + velocidad +
                ", fuerza=" + fuerza +
                ", resistencia=" + resistencia +
                '}';
    }

}
